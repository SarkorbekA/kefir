console.log('Welcome');
console.log('Developed by Sarkor');



// const burgerOpen = document.querySelector('.nav__open');
// const burgerClose = document.querySelector('.nav__exit-btn');
// const burgerMenu = document.querySelector('.header-content');
// const body = document.querySelector('body');
// const filter = document.querySelector('.filter');

// burgerOpen.addEventListener('click', () =>{
//     burgerMenu.classList.add('active')
//     body.classList.add('active')
//     filter.classList.add('active')
// })

// burgerClose.addEventListener('click', () =>{
//     burgerMenu.classList.remove('active')
//     body.classList.remove('active')
//     filter.classList.remove('active')
// })

// filter.addEventListener('click', () =>{
//     burgerMenu.classList.remove('active')
//     body.classList.remove('active')
//     filter.classList.remove('active')
// })


const langBtn = document.querySelector('.header__lang-title');
const langList = document.querySelector('.header__lang-list');

langBtn.addEventListener('click', () => {
    langList.classList.toggle('active');
})




var options = {
    // rootMargin: '120px',
    rootMargin: '10px',
    threshold: [0, .25, .50, .75, 1]
    // threshold: 1,
}

var callback = function (entries, observer) {
    entries.forEach(el => {
        if (el.isIntersecting && el.intersectionRatio > .6) {
            el.target.classList.add('reveal-after')
        } else {
            el.target.classList.remove('reveal-after');
        }
    })
};

var observer = new IntersectionObserver(callback, options);

document.querySelectorAll('.card').forEach(el => {
    observer.observe(el);
})

// document.querySelectorAll('.reveal-left').forEach(el => {
//     observer.observe(el);
// })
// document.querySelectorAll('.reveal-right').forEach(el => {
//     observer.observe(el);
// })
// document.querySelectorAll('.reveal-top').forEach(el => {
//     observer.observe(el);
// })
// document.querySelectorAll('.reveal-bottom').forEach(el => {
//     observer.observe(el);
// })